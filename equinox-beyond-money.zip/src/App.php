<?php

declare(strict_types=1);

namespace Equinox;

use PDO;
use PDOStatement;
use RuntimeException;
use Throwable;

final class App
{
    private ?PDO $db = null;

    public function run(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';

        try {
            if ($path === '/' && $method === 'GET') {
                $this->serveFile(dirname(__DIR__) . '/templates/app.html', 'text/html; charset=UTF-8');
                return;
            }

            if ($path === '/assets/styles.css' && $method === 'GET') {
                $this->serveFile(dirname(__DIR__) . '/templates/styles.css', 'text/css');
                return;
            }

            if ($path === '/assets/app.js' && $method === 'GET') {
                $this->serveFile(dirname(__DIR__) . '/templates/app.js', 'application/javascript');
                return;
            }

            if (!str_starts_with($path, '/api')) {
                http_response_code(404);
                echo 'Not Found';
                return;
            }

            $this->route($method, $path);
        } catch (Throwable $exception) {
            Response::json([
                'success' => false,
                'error' => $exception->getMessage(),
            ], 500);
        }
    }

    private function route(string $method, string $path): void
    {
        $input = $this->input();

        if ($method === 'GET' && $path === '/api/health') {
            Response::json([
                'success' => true,
                'message' => 'Equinox API is healthy',
                'timestamp' => date(DATE_ATOM),
            ]);
            return;
        }

        if ($method === 'POST' && $path === '/api/register') {
            $this->register($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/login') {
            $this->login($input);
            return;
        }

        if ($method === 'GET' && $path === '/api/bootstrap') {
            $this->bootstrap();
            return;
        }

        if ($method === 'POST' && $path === '/api/wallet/activate') {
            $this->activateWallet($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/wallet/transfer') {
            $this->transferEq($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/cards') {
            $this->createCard($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/cards/freeze') {
            $this->toggleCardFreeze($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/pools') {
            $this->createPool($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/pools/contribute') {
            $this->contributePool($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/skills') {
            $this->createSkill($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/contracts') {
            $this->createContract($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/contracts/settle') {
            $this->settleContract($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/reviews') {
            $this->createReview($input);
            return;
        }

        if ($method === 'POST' && $path === '/api/query-demonstrator') {
            $this->queryDemonstrator($input);
            return;
        }

        if ($method === 'GET' && $path === '/api/stream') {
            $this->stream();
            return;
        }

        Response::json(['success' => false, 'error' => 'Endpoint not found'], 404);
    }

    private function register(array $input): void
    {
        $db = $this->db();
        $name = trim((string) ($input['full_name'] ?? ''));
        $email = trim((string) ($input['email'] ?? ''));
        $password = (string) ($input['password'] ?? '');
        $dob = trim((string) ($input['date_of_birth'] ?? ''));
        $phone = trim((string) ($input['phone_number'] ?? ''));
        $city = trim((string) ($input['location_city'] ?? ''));

        if ($name === '' || $email === '' || $password === '' || $dob === '') {
            Response::json(['success' => false, 'error' => 'Please complete all required fields'], 422);
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Response::json(['success' => false, 'error' => 'Enter a valid email address'], 422);
            return;
        }

        if (strlen($password) < 6) {
            Response::json(['success' => false, 'error' => 'Password must be at least 6 characters long'], 422);
            return;
        }

        if ($phone !== '' && !preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
            Response::json(['success' => false, 'error' => 'Enter a valid phone number'], 422);
            return;
        }

        if (!$this->isDate($dob)) {
            Response::json(['success' => false, 'error' => 'Enter a valid date of birth'], 422);
            return;
        }

        $stmt = $db->prepare('SELECT user_id FROM users_profile WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            Response::json(['success' => false, 'error' => 'This email is already registered'], 409);
            return;
        }

        $userId = $this->uuid();
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $db->beginTransaction();
        try {
            $db->prepare(
                'INSERT INTO users_profile (
                    user_id, full_name, email, password_hash, phone_number, date_of_birth, location_city
                ) VALUES (?, ?, ?, ?, ?, ?, ?)'
            )->execute([$userId, $name, $email, $hashedPassword, $phone ?: null, $dob, $city ?: null]);

            $db->prepare('INSERT INTO user_settings (user_id) VALUES (?)')->execute([$userId]);
            $db->prepare('INSERT INTO wallets_equinox (wallet_id, user_id) VALUES (?, ?)')->execute([$this->uuid(), $userId]);

            $db->commit();
        } catch (Throwable $exception) {
            $db->rollBack();
            throw $exception;
        }

        Response::json([
            'success' => true,
            'message' => 'Registration completed successfully. Please sign in.',
        ]);
    }

    private function login(array $input): void
    {
        $db = $this->db();
        Env::load(dirname(__DIR__) . '/.env');
        $secret = Env::get('JWT_SECRET', 'secret');
        $email = trim((string) ($input['email'] ?? ''));
        $password = (string) ($input['password'] ?? '');

        if ($email === '' || $password === '') {
            Response::json(['success' => false, 'error' => 'Email and password are required'], 422);
            return;
        }

        $stmt = $db->prepare(
            'SELECT user_id, full_name, email, password_hash
             FROM users_profile
             WHERE email = ?'
        );
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, (string) $user['password_hash'])) {
            Response::json(['success' => false, 'error' => 'Invalid email or password'], 401);
            return;
        }

        $token = Jwt::encode([
            'sub' => $user['user_id'],
            'email' => $user['email'],
            'name' => $user['full_name'],
            'exp' => time() + (60 * 60 * 8),
        ], $secret);

        $this->recordLogin((string) $user['user_id']);

        Response::json([
            'success' => true,
            'token' => $token,
        ]);
    }

    private function bootstrap(): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $userId = (string) $auth['sub'];

        $profileStmt = $db->prepare(
            'SELECT
                u.user_id,
                u.full_name,
                u.email,
                u.phone_number,
                u.location_city,
                u.kyc_status,
                u.trust_score,
                u.created_at,
                w.wallet_id,
                w.balance,
                w.status,
                w.activated_at
             FROM users_profile u
             JOIN wallets_equinox w ON w.user_id = u.user_id
             WHERE u.user_id = ?'
        );
        $profileStmt->execute([$userId]);
        $profile = $profileStmt->fetch();

        if (!$profile) {
            Response::json(['success' => false, 'error' => 'Profile not found'], 404);
            return;
        }

        $walletId = (string) $profile['wallet_id'];

        $insightsStmt = $db->prepare(
            'SELECT
                COALESCE(SUM(CASE WHEN sender_wallet = ? THEN amount ELSE 0 END), 0) AS total_sent_eq,
                COALESCE(SUM(CASE WHEN receiver_wallet = ? THEN amount ELSE 0 END), 0) AS total_received_eq,
                COUNT(*) AS ledger_count
             FROM transactions_master
             WHERE sender_wallet = ? OR receiver_wallet = ?'
        );
        $insightsStmt->execute([$walletId, $walletId, $walletId, $walletId]);
        $insights = $insightsStmt->fetch() ?: [];

        $transactions = $db->prepare(
            'SELECT
                t.transaction_id,
                t.sender_wallet,
                t.receiver_wallet,
                t.amount,
                t.transaction_type,
                t.status,
                t.note,
                t.latitude,
                t.longitude,
                t.created_at,
                s.full_name AS sender_name,
                r.full_name AS receiver_name
             FROM transactions_master t
             LEFT JOIN wallets_equinox sw ON sw.wallet_id = t.sender_wallet
             LEFT JOIN users_profile s ON s.user_id = sw.user_id
             LEFT JOIN wallets_equinox rw ON rw.wallet_id = t.receiver_wallet
             LEFT JOIN users_profile r ON r.user_id = rw.user_id
             WHERE t.sender_wallet = ? OR t.receiver_wallet = ?
             ORDER BY t.created_at DESC
             LIMIT 14'
        );
        $transactions->execute([$walletId, $walletId]);

        $notifications = $db->prepare(
            'SELECT notif_id, title, body, notif_type, is_read, created_at
             FROM notifications
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT 12'
        );
        $notifications->execute([$userId]);

        $cards = $db->prepare(
            'SELECT card_id, card_number, expiry_date, card_name, is_frozen, created_at
             FROM equinox_cards
             WHERE wallet_id = ?
             ORDER BY created_at DESC'
        );
        $cards->execute([$walletId]);

        $pools = $db->query(
            'SELECT
                p.pool_id,
                p.creator_id,
                p.title,
                p.description,
                p.target_amount,
                p.raised_amount,
                p.deadline,
                p.status,
                p.verified,
                p.created_at,
                u.full_name AS creator_name,
                COUNT(pc.contrib_id) AS contribution_count
             FROM community_pools p
             JOIN users_profile u ON u.user_id = p.creator_id
             LEFT JOIN pool_contributions pc ON pc.pool_id = p.pool_id
             GROUP BY
                p.pool_id, p.creator_id, p.title, p.description, p.target_amount, p.raised_amount,
                p.deadline, p.status, p.verified, p.created_at, u.full_name
             ORDER BY p.created_at DESC
             LIMIT 12'
        )->fetchAll();

        $skills = $db->query(
            'SELECT
                s.skill_id,
                s.user_id,
                s.skill_name,
                s.description,
                s.rate_per_hour,
                s.is_active,
                s.created_at,
                u.full_name,
                w.wallet_id AS provider_wallet
             FROM skill_listings s
             JOIN users_profile u ON u.user_id = s.user_id
             JOIN wallets_equinox w ON w.user_id = u.user_id
             WHERE s.is_active = 1
             ORDER BY s.created_at DESC
             LIMIT 12'
        )->fetchAll();

        $contracts = $db->prepare(
            'SELECT
                c.contract_id,
                c.provider_id,
                c.consumer_id,
                c.skill_id,
                c.hours,
                c.total_eq,
                c.status,
                c.created_at,
                p.full_name AS provider_name,
                n.full_name AS consumer_name,
                s.skill_name
             FROM service_contracts c
             JOIN users_profile p ON p.user_id = c.provider_id
             JOIN users_profile n ON n.user_id = c.consumer_id
             JOIN skill_listings s ON s.skill_id = c.skill_id
             WHERE c.provider_id = ? OR c.consumer_id = ?
             ORDER BY c.created_at DESC'
        );
        $contracts->execute([$userId, $userId]);

        $trustHistory = $db->prepare(
            'SELECT log_id, score_delta, reason, created_at
             FROM trust_history
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT 10'
        );
        $trustHistory->execute([$userId]);

        $directory = $db->prepare(
            'SELECT
                u.user_id,
                u.full_name,
                u.location_city,
                u.kyc_status,
                u.trust_score,
                w.wallet_id,
                w.status AS wallet_status,
                COUNT(DISTINCT s.skill_id) AS skill_count
             FROM users_profile u
             JOIN wallets_equinox w ON w.user_id = u.user_id
             LEFT JOIN skill_listings s ON s.user_id = u.user_id AND s.is_active = 1
             WHERE u.user_id <> ?
             GROUP BY
                u.user_id, u.full_name, u.location_city, u.kyc_status, u.trust_score, w.wallet_id, w.status
             ORDER BY u.trust_score DESC, u.created_at DESC
             LIMIT 20'
        );
        $directory->execute([$userId]);

        $loginHistory = $db->prepare(
            'SELECT log_id, device_fingerprint, ip_address, login_status, created_at
             FROM login_history
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT 6'
        );
        $loginHistory->execute([$userId]);

        $cardCountStmt = $db->prepare('SELECT COUNT(*) AS total_cards FROM equinox_cards WHERE wallet_id = ?');
        $cardCountStmt->execute([$walletId]);
        $cardCount = (int) (($cardCountStmt->fetch()['total_cards'] ?? 0));

        Response::json([
            'success' => true,
            'profile' => $profile,
            'insights' => [
                'total_sent_eq' => (float) ($insights['total_sent_eq'] ?? 0),
                'total_received_eq' => (float) ($insights['total_received_eq'] ?? 0),
                'ledger_count' => (int) ($insights['ledger_count'] ?? 0),
                'card_count' => $cardCount,
                'account_age_days' => $this->daysSince((string) $profile['created_at']),
            ],
            'transactions' => $transactions->fetchAll(),
            'notifications' => $notifications->fetchAll(),
            'cards' => array_map(fn (array $card): array => $this->mapCardForDisplay($card), $cards->fetchAll()),
            'pools' => array_map(fn (array $pool): array => $this->mapPoolForDisplay($pool), $pools),
            'skills' => $skills,
            'contracts' => $contracts->fetchAll(),
            'trust_history' => $trustHistory->fetchAll(),
            'directory' => $directory->fetchAll(),
            'login_history' => $loginHistory->fetchAll(),
            'query_presets' => $this->queryPresetMeta(),
        ]);
    }

    private function activateWallet(array $input): void
    {
        $auth = $this->requireUser();
        $result = $this->callProcedure('CALL activate_wallet(?, ?, ?)', [
            $auth['sub'],
            $input['latitude'] ?? null,
            $input['longitude'] ?? null,
        ]);

        Response::json($result ?: ['success' => false, 'error' => 'Activation failed']);
    }

    private function transferEq(array $input): void
    {
        $auth = $this->requireUser();
        $senderWallet = $this->findWalletForUser((string) $auth['sub']);
        $receiverWallet = trim((string) ($input['receiver_wallet'] ?? ''));
        $amount = (float) ($input['amount'] ?? 0);
        $note = trim((string) ($input['note'] ?? ''));
        $cardId = trim((string) ($input['card_id'] ?? ''));

        if (!$this->isUuid($receiverWallet)) {
            Response::json(['success' => false, 'error' => 'Enter a valid receiver wallet ID'], 422);
            return;
        }

        if ($amount <= 0) {
            Response::json(['success' => false, 'error' => 'Enter a valid amount'], 422);
            return;
        }

        if ($cardId !== '') {
            try {
                $card = $this->validateTransferCard((string) $auth['sub'], $cardId);
                $note = trim($note . ' | Paid using ' . ($card['masked_card_number'] ?? ''));
            } catch (RuntimeException $exception) {
                Response::json(['success' => false, 'error' => $exception->getMessage()], 422);
                return;
            }
        }

        $result = $this->callProcedure('CALL transfer_eq(?, ?, ?, ?, ?, ?)', [
            $senderWallet['wallet_id'],
            $receiverWallet,
            $amount,
            $note ?: null,
            $input['latitude'] ?? null,
            $input['longitude'] ?? null,
        ]);

        Response::json($result ?: ['success' => false, 'error' => 'Transfer failed']);
    }

    private function createCard(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $wallet = $this->findWalletForUser((string) $auth['sub']);
        $cardName = trim((string) ($input['card_name'] ?? 'Primary'));

        if ((string) $wallet['status'] !== 'ACTIVE') {
            Response::json(['success' => false, 'error' => 'Activate your wallet before creating cards'], 422);
            return;
        }

        if ($cardName === '') {
            $cardName = 'Primary';
        }

        $cardNumber = $this->formatCardNumber($this->generateCardNumber());
        $cvv = (string) random_int(100, 999);
        $expiryDate = date('m/y', strtotime('+4 years'));

        try {
            $stmt = $db->prepare(
                'INSERT INTO equinox_cards (card_id, wallet_id, card_number, cvv_hash, expiry_date, card_name)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $this->uuid(),
                $wallet['wallet_id'],
                $cardNumber,
                password_hash($cvv, PASSWORD_DEFAULT),
                $expiryDate,
                mb_substr($cardName, 0, 30),
            ]);
        } catch (Throwable $exception) {
            Response::json(['success' => false, 'error' => $exception->getMessage()], 422);
            return;
        }

        Response::json([
            'success' => true,
            'message' => 'Virtual card created successfully',
            'card' => [
                'card_number' => $cardNumber,
                'masked_card_number' => $this->maskCardNumber($cardNumber),
                'expiry_date' => $expiryDate,
                'cvv' => $cvv,
                'card_name' => $cardName,
            ],
        ]);
    }

    private function toggleCardFreeze(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $cardId = trim((string) ($input['card_id'] ?? ''));

        if (!$this->isUuid($cardId)) {
            Response::json(['success' => false, 'error' => 'Invalid card selected'], 422);
            return;
        }

        $stmt = $db->prepare(
            'SELECT c.card_id, c.card_number, c.is_frozen
             FROM equinox_cards c
             JOIN wallets_equinox w ON w.wallet_id = c.wallet_id
             WHERE c.card_id = ? AND w.user_id = ?'
        );
        $stmt->execute([$cardId, $auth['sub']]);
        $card = $stmt->fetch();

        if (!$card) {
            Response::json(['success' => false, 'error' => 'Card not found'], 404);
            return;
        }

        $newState = array_key_exists('is_frozen', $input)
            ? ($this->toBool($input['is_frozen']) ? 1 : 0)
            : ((int) $card['is_frozen'] === 1 ? 0 : 1);

        $db->prepare('UPDATE equinox_cards SET is_frozen = ? WHERE card_id = ?')->execute([$newState, $cardId]);

        Response::json([
            'success' => true,
            'message' => $newState === 1 ? 'Card frozen successfully' : 'Card unfrozen successfully',
            'card' => [
                'card_id' => $cardId,
                'is_frozen' => $newState === 1,
                'masked_card_number' => $this->maskCardNumber((string) $card['card_number']),
            ],
        ]);
    }

    private function createPool(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $title = trim((string) ($input['title'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $targetAmount = (float) ($input['target_amount'] ?? 0);
        $deadline = trim((string) ($input['deadline'] ?? ''));

        if ($title === '' || $targetAmount <= 0 || $deadline === '') {
            Response::json(['success' => false, 'error' => 'Enter title, target amount, and deadline'], 422);
            return;
        }

        $stmt = $db->prepare(
            'INSERT INTO community_pools (
                pool_id, creator_id, title, description, target_amount, deadline, verified
            ) VALUES (?, ?, ?, ?, ?, ?, 1)'
        );
        $stmt->execute([
            $this->uuid(),
            $auth['sub'],
            $title,
            $description ?: null,
            $targetAmount,
            $deadline,
        ]);

        Response::json(['success' => true, 'message' => 'Community pool created']);
    }

    private function contributePool(array $input): void
    {
        $auth = $this->requireUser();
        $wallet = $this->findWalletForUser((string) $auth['sub']);
        $poolId = trim((string) ($input['pool_id'] ?? ''));
        $amount = (float) ($input['amount'] ?? 0);

        if (!$this->isUuid($poolId) || $amount <= 0) {
            Response::json(['success' => false, 'error' => 'Enter a valid pool and contribution amount'], 422);
            return;
        }

        $result = $this->callProcedure('CALL contribute_pool(?, ?, ?)', [
            $wallet['wallet_id'],
            $poolId,
            $amount,
        ]);

        Response::json($result ?: ['success' => false, 'error' => 'Contribution failed']);
    }

    private function createSkill(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $skillName = trim((string) ($input['skill_name'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $ratePerHour = (int) ($input['rate_per_hour'] ?? 0);

        if ($skillName === '' || $ratePerHour <= 0) {
            Response::json(['success' => false, 'error' => 'Enter skill name and a valid hourly rate'], 422);
            return;
        }

        $db->prepare(
            'INSERT INTO skill_listings (skill_id, user_id, skill_name, description, rate_per_hour)
             VALUES (?, ?, ?, ?, ?)'
        )->execute([
            $this->uuid(),
            $auth['sub'],
            $skillName,
            $description ?: null,
            $ratePerHour,
        ]);

        Response::json(['success' => true, 'message' => 'Skill listed successfully']);
    }

    private function createContract(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $skillId = trim((string) ($input['skill_id'] ?? ''));
        $hours = (int) ($input['hours'] ?? 0);

        if (!$this->isUuid($skillId) || $hours <= 0) {
            Response::json(['success' => false, 'error' => 'Select a skill and valid hours'], 422);
            return;
        }

        $skillStmt = $db->prepare('SELECT user_id, rate_per_hour FROM skill_listings WHERE skill_id = ? AND is_active = 1');
        $skillStmt->execute([$skillId]);
        $skill = $skillStmt->fetch();

        if (!$skill) {
            Response::json(['success' => false, 'error' => 'Skill listing not found'], 404);
            return;
        }

        if ((string) $skill['user_id'] === (string) $auth['sub']) {
            Response::json(['success' => false, 'error' => 'You cannot create a contract with your own listing'], 422);
            return;
        }

        $totalEq = $hours * (int) $skill['rate_per_hour'];

        $db->prepare(
            'INSERT INTO service_contracts (contract_id, provider_id, consumer_id, skill_id, hours, total_eq)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([
            $this->uuid(),
            $skill['user_id'],
            $auth['sub'],
            $skillId,
            $hours,
            $totalEq,
        ]);

        Response::json([
            'success' => true,
            'message' => 'Contract created successfully',
            'total_eq' => $totalEq,
        ]);
    }

    private function settleContract(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $contractId = trim((string) ($input['contract_id'] ?? ''));

        if (!$this->isUuid($contractId)) {
            Response::json(['success' => false, 'error' => 'Invalid contract selected'], 422);
            return;
        }

        $contractStmt = $db->prepare(
            'SELECT contract_id, provider_id, consumer_id, status
             FROM service_contracts
             WHERE contract_id = ?'
        );
        $contractStmt->execute([$contractId]);
        $contract = $contractStmt->fetch();

        if (!$contract) {
            Response::json(['success' => false, 'error' => 'Contract not found'], 404);
            return;
        }

        if ((string) $contract['provider_id'] !== (string) $auth['sub'] && (string) $contract['consumer_id'] !== (string) $auth['sub']) {
            Response::json(['success' => false, 'error' => 'You cannot settle this contract'], 403);
            return;
        }

        $consumerWallet = $this->findWalletForUser((string) $contract['consumer_id']);
        $providerWallet = $this->findWalletForUser((string) $contract['provider_id']);

        $result = $this->callProcedure('CALL settle_contract(?, ?, ?)', [
            $contractId,
            $consumerWallet['wallet_id'],
            $providerWallet['wallet_id'],
        ]);

        Response::json($result ?: ['success' => false, 'error' => 'Contract settlement failed']);
    }

    private function createReview(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $contractId = trim((string) ($input['contract_id'] ?? ''));
        $subjectId = trim((string) ($input['subject_id'] ?? ''));
        $rating = (int) ($input['rating'] ?? 0);
        $comment = trim((string) ($input['comment'] ?? ''));

        if ($rating < 1 || $rating > 5) {
            Response::json(['success' => false, 'error' => 'Rating must be between 1 and 5'], 422);
            return;
        }

        if ($contractId !== '') {
            $contractStmt = $db->prepare(
                'SELECT contract_id, provider_id, consumer_id, status
                 FROM service_contracts
                 WHERE contract_id = ?'
            );
            $contractStmt->execute([$contractId]);
            $contract = $contractStmt->fetch();

            if (!$contract) {
                Response::json(['success' => false, 'error' => 'Contract not found'], 404);
                return;
            }

            if ((string) $contract['provider_id'] !== (string) $auth['sub'] && (string) $contract['consumer_id'] !== (string) $auth['sub']) {
                Response::json(['success' => false, 'error' => 'You cannot review this contract'], 403);
                return;
            }

            if ((string) $contract['status'] !== 'COMPLETED') {
                Response::json(['success' => false, 'error' => 'Reviews can only be added after settlement'], 422);
                return;
            }

            if ($subjectId === '') {
                $subjectId = (string) $contract['provider_id'] === (string) $auth['sub']
                    ? (string) $contract['consumer_id']
                    : (string) $contract['provider_id'];
            }
        }

        if (!$this->isUuid($subjectId) || $subjectId === (string) $auth['sub']) {
            Response::json(['success' => false, 'error' => 'Select a valid citizen to review'], 422);
            return;
        }

        $db->prepare(
            'INSERT INTO user_reviews (review_id, reviewer_id, subject_id, contract_id, rating, comment)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([
            $this->uuid(),
            $auth['sub'],
            $subjectId,
            $contractId ?: null,
            $rating,
            $comment ?: null,
        ]);

        Response::json(['success' => true, 'message' => 'Review submitted successfully']);
    }

    private function queryDemonstrator(array $input): void
    {
        $db = $this->db();
        $auth = $this->requireUser();
        $preset = trim((string) ($input['preset'] ?? ''));
        $sql = trim((string) ($input['sql'] ?? ''));
        $params = [];

        try {
            if ($preset !== '') {
                [$sql, $params] = $this->presetQuery($preset, (string) $auth['sub']);
            } elseif ($sql !== '') {
                $sql = $this->sanitizeReadOnlySql($sql);
            } else {
                Response::json(['success' => false, 'error' => 'Choose a preset or enter a read-only query'], 422);
                return;
            }

            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            $columns = $this->queryColumns($stmt, $rows);
        } catch (Throwable $exception) {
            Response::json(['success' => false, 'error' => $exception->getMessage()], 422);
            return;
        }

        Response::json([
            'success' => true,
            'query' => $sql,
            'columns' => $columns,
            'rows' => $rows,
            'row_count' => count($rows),
            'executed_at' => date(DATE_ATOM),
        ]);
    }

    private function stream(): void
    {
        $auth = $this->requireUser();
        $wallet = $this->findWalletForUser((string) $auth['sub']);

        Response::json($this->fetchLiveState((string) $auth['sub'], (string) $wallet['wallet_id']));
    }

    private function fetchLiveState(string $userId, string $walletId): array
    {
        $db = $this->db();
        $walletStmt = $db->prepare(
            'SELECT balance, status, updated_at
             FROM wallets_equinox
             WHERE wallet_id = ?'
        );
        $walletStmt->execute([$walletId]);

        $notificationStmt = $db->prepare(
            'SELECT COUNT(*) AS unread_count, MAX(created_at) AS latest_notification
             FROM notifications
             WHERE user_id = ? AND is_read = 0'
        );
        $notificationStmt->execute([$userId]);

        $transactionStmt = $db->prepare(
            'SELECT COUNT(*) AS total_txns, MAX(created_at) AS latest_txn
             FROM transactions_master
             WHERE sender_wallet = ? OR receiver_wallet = ?'
        );
        $transactionStmt->execute([$walletId, $walletId]);

        return [
            'success' => true,
            'wallet' => $walletStmt->fetch(),
            'notifications' => $notificationStmt->fetch(),
            'transactions' => $transactionStmt->fetch(),
            'server_time' => date(DATE_ATOM),
        ];
    }

    private function callProcedure(string $sql, array $params): array
    {
        $stmt = $this->db()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch() ?: [];
        while ($stmt->nextRowset()) {
        }
        $stmt->closeCursor();
        return $result;
    }

    private function validateTransferCard(string $userId, string $cardId): array
    {
        $db = $this->db();
        $stmt = $db->prepare(
            'SELECT c.card_id, c.card_number, c.is_frozen
             FROM equinox_cards c
             JOIN wallets_equinox w ON w.wallet_id = c.wallet_id
             WHERE c.card_id = ? AND w.user_id = ?'
        );
        $stmt->execute([$cardId, $userId]);
        $card = $stmt->fetch();

        if (!$card) {
            throw new RuntimeException('Selected card was not found');
        }

        if ((int) $card['is_frozen'] === 1) {
            throw new RuntimeException('Selected card is frozen');
        }

        return [
            'card_id' => $card['card_id'],
            'masked_card_number' => $this->maskCardNumber((string) $card['card_number']),
        ];
    }

    private function recordLogin(string $userId): void
    {
        $stmt = $this->db()->prepare(
            'INSERT INTO login_history (log_id, user_id, device_fingerprint, ip_address, login_status)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $this->uuid(),
            $userId,
            mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown device'), 0, 255),
            mb_substr((string) ($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'), 0, 45),
            'SUCCESS',
        ]);
    }

    private function requireUser(): array
    {
        $user = Auth::user();
        if (!$user) {
            Response::json(['success' => false, 'error' => 'Unauthorized'], 401);
            exit;
        }

        return $user;
    }

    private function input(): array
    {
        $raw = file_get_contents('php://input') ?: '';
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function serveFile(string $path, string $contentType): void
    {
        header('Content-Type: ' . $contentType);
        readfile($path);
    }

    private function queryColumns(PDOStatement $stmt, array $rows): array
    {
        if (!empty($rows)) {
            return array_keys($rows[0]);
        }

        $columns = [];
        for ($index = 0; $index < $stmt->columnCount(); $index++) {
            $meta = $stmt->getColumnMeta($index);
            if (is_array($meta) && isset($meta['name'])) {
                $columns[] = $meta['name'];
            }
        }

        return $columns;
    }

    private function presetQuery(string $preset, string $userId): array
    {
        $wallet = $this->findWalletForUser($userId);

        $map = [
            'wallet_summary' => [
                'sql' => 'SELECT
                    u.full_name,
                    u.trust_score,
                    u.kyc_status,
                    w.wallet_id,
                    w.balance,
                    w.status,
                    ts.total_sent,
                    ts.total_received,
                    ts.completed_contracts
                 FROM users_profile u
                 JOIN wallets_equinox w ON w.user_id = u.user_id
                 LEFT JOIN trust_scores ts ON ts.user_id = u.user_id
                 WHERE u.user_id = ?',
                'params' => [$userId],
            ],
            'recent_ledger' => [
                'sql' => 'SELECT
                    t.transaction_id,
                    t.transaction_type,
                    t.amount,
                    t.status,
                    t.note,
                    t.created_at,
                    sender.full_name AS sender_name,
                    receiver.full_name AS receiver_name
                 FROM transactions_master t
                 LEFT JOIN wallets_equinox sw ON sw.wallet_id = t.sender_wallet
                 LEFT JOIN users_profile sender ON sender.user_id = sw.user_id
                 LEFT JOIN wallets_equinox rw ON rw.wallet_id = t.receiver_wallet
                 LEFT JOIN users_profile receiver ON receiver.user_id = rw.user_id
                 ORDER BY t.created_at DESC
                 LIMIT 15',
                'params' => [],
            ],
            'cards_matrix' => [
                'sql' => 'SELECT
                    card_name,
                    card_number,
                    expiry_date,
                    is_frozen,
                    created_at
                 FROM equinox_cards
                 WHERE wallet_id = ?
                 ORDER BY created_at DESC',
                'params' => [$wallet['wallet_id']],
            ],
            'pool_progress' => [
                'sql' => 'SELECT
                    title,
                    target_amount,
                    raised_amount,
                    ROUND((raised_amount / NULLIF(target_amount, 0)) * 100, 2) AS progress_percent,
                    deadline,
                    status
                 FROM community_pools
                 ORDER BY created_at DESC
                 LIMIT 15',
                'params' => [],
            ],
            'trust_audit' => [
                'sql' => 'SELECT score_delta, reason, created_at
                 FROM trust_history
                 WHERE user_id = ?
                 ORDER BY created_at DESC
                 LIMIT 20',
                'params' => [$userId],
            ],
            'security_logins' => [
                'sql' => 'SELECT device_fingerprint, ip_address, login_status, created_at
                 FROM login_history
                 WHERE user_id = ?
                 ORDER BY created_at DESC
                 LIMIT 20',
                'params' => [$userId],
            ],
        ];

        if (!isset($map[$preset])) {
            throw new RuntimeException('Unknown query preset selected');
        }

        return [$map[$preset]['sql'], $map[$preset]['params']];
    }

    private function sanitizeReadOnlySql(string $sql): string
    {
        $sql = trim($sql);
        $sql = preg_replace('/;\s*$/', '', $sql) ?? $sql;

        if (strpos($sql, ';') !== false) {
            throw new RuntimeException('Only a single read-only query is allowed');
        }

        if (!preg_match('/^\s*(select|show|describe|desc|explain)\b/i', $sql)) {
            throw new RuntimeException('Only SELECT, SHOW, DESCRIBE, DESC, or EXPLAIN queries are allowed');
        }

        if (preg_match('/\b(insert|update|delete|drop|alter|truncate|create|replace|grant|revoke|call|commit|rollback)\b/i', $sql)) {
            throw new RuntimeException('Write operations are blocked in the query demonstrator');
        }

        if (preg_match('/^\s*select\b/i', $sql) && !preg_match('/\blimit\b/i', $sql)) {
            $sql .= ' LIMIT 50';
        }

        return $sql;
    }

    private function mapCardForDisplay(array $card): array
    {
        $cardNumber = (string) $card['card_number'];

        return [
            'card_id' => $card['card_id'],
            'card_name' => $card['card_name'],
            'card_number' => $cardNumber,
            'masked_card_number' => $this->maskCardNumber($cardNumber),
            'expiry_date' => $card['expiry_date'],
            'is_frozen' => (int) $card['is_frozen'] === 1,
            'created_at' => $card['created_at'],
            'brand' => str_starts_with(str_replace(' ', '', $cardNumber), '4') ? 'VISA' : 'EQUINOX',
        ];
    }

    private function mapPoolForDisplay(array $pool): array
    {
        $target = (float) $pool['target_amount'];
        $raised = (float) $pool['raised_amount'];
        $progress = $target > 0 ? round(($raised / $target) * 100, 2) : 0;
        $pool['progress_percent'] = min(100, max(0, $progress));
        return $pool;
    }

    private function queryPresetMeta(): array
    {
        return [
            ['id' => 'wallet_summary', 'label' => 'Wallet Summary', 'description' => 'Wallet, trust, and ledger counters for the signed-in citizen'],
            ['id' => 'recent_ledger', 'label' => 'Recent Ledger', 'description' => 'Live joined transaction history with sender and receiver names'],
            ['id' => 'cards_matrix', 'label' => 'Cards Matrix', 'description' => 'Generated cards, freeze flags, and expiry information'],
            ['id' => 'pool_progress', 'label' => 'Pool Progress', 'description' => 'Community pools with funding percentages from live DB values'],
            ['id' => 'trust_audit', 'label' => 'Trust Audit', 'description' => 'Trust-score changes produced by the review trigger'],
            ['id' => 'security_logins', 'label' => 'Security Logins', 'description' => 'Recent login activity with device and IP data'],
        ];
    }

    private function findWalletForUser(string $userId): array
    {
        $stmt = $this->db()->prepare(
            'SELECT wallet_id, balance, status
             FROM wallets_equinox
             WHERE user_id = ?'
        );
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch();

        if (!$wallet) {
            throw new RuntimeException('Wallet not found');
        }

        return $wallet;
    }

    private function generateCardNumber(): string
    {
        $body = '5278';
        for ($index = 0; $index < 11; $index++) {
            $body .= (string) random_int(0, 9);
        }

        return $body . $this->luhnCheckDigit($body);
    }

    private function luhnCheckDigit(string $number): int
    {
        $sum = 0;
        $reversed = strrev($number);

        for ($index = 0, $length = strlen($reversed); $index < $length; $index++) {
            $digit = (int) $reversed[$index];
            if ($index % 2 === 0) {
                $digit *= 2;
                if ($digit > 9) {
                    $digit -= 9;
                }
            }
            $sum += $digit;
        }

        return (10 - ($sum % 10)) % 10;
    }

    private function formatCardNumber(string $number): string
    {
        return trim(chunk_split($number, 4, ' '));
    }

    private function maskCardNumber(string $cardNumber): string
    {
        $digits = preg_replace('/\D+/', '', $cardNumber) ?? $cardNumber;
        return '**** **** **** ' . substr($digits, -4);
    }

    private function isDate(string $value): bool
    {
        return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $value);
    }

    private function isUuid(string $value): bool
    {
        return (bool) preg_match(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
            $value
        );
    }

    private function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        return in_array(strtolower((string) $value), ['1', 'true', 'yes', 'on'], true);
    }

    private function daysSince(string $timestamp): int
    {
        $time = strtotime($timestamp);
        if ($time === false) {
            return 0;
        }

        return max(0, (int) floor((time() - $time) / 86400));
    }

    private function uuid(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    private function db(): PDO
    {
        if (!$this->db instanceof PDO) {
            $this->db = Database::connection();
        }

        return $this->db;
    }
}
