# Equinox Beyond Money

Equinox is a lightweight PHP + MySQL implementation of the DBMS mini project you described. It runs with a MySQL-only backend, works with MySQL Workbench on `localhost:3306`, includes stored procedures and triggers, and gives you a full command-center style UI for registration, wallet activation, QR payments, cards, pools, skills, contracts, trust scoring, and live DBMS query demonstrations.

## Why this stack

I used PHP instead of Node so the project stays simple:

- No npm install is required.
- The backend runs with the built-in PHP server.
- MySQL remains the only database.
- QR libraries are already vendored inside the project for offline demo use.
- Realtime is kept lightweight through periodic live refresh against the PHP API.

## MySQL Workbench connection

Use these exact values in MySQL Workbench:

- Connection Name: `Equinox DBMS`
- Connection Method: `Standard (TCP/IP)`
- Hostname: `localhost`
- Port: `3306`
- Username: `root`
- Password: store it in Workbench vault
- Default Schema: `equinox_dbms`

## Project structure

- [database/schema.sql](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/database/schema.sql)
- [public/index.php](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/public/index.php)
- [src/App.php](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/src/App.php)
- [templates/app.html](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/templates/app.html)
- [templates/styles.css](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/templates/styles.css)
- [templates/app.js](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/templates/app.js)

## Setup from unzip to running

1. Unzip the project into a folder, for example:
   `C:\Users\saira\Documents\Codex\2026-04-24\equinox-beyond-money-full-system-design`

2. Copy `.env.example` to `.env`

3. Edit `.env` and keep your MySQL details like this:

```dotenv
VITE_API_URL=http://localhost:3002/api
BACKEND_PORT=3002
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=YOUR_MYSQL_PASSWORD
DB_NAME=equinox_dbms
JWT_SECRET=equinox_jwt_secret_min_32_characters_long_for_prod_security_here_1234
VITE_RAZORPAY_KEY_ID=rzp_test_RzYF4GJPLG8zoR
VITE_RAZORPAY_KEY_SECRET=fpRado9evw4btr4uRDkGaxz0
VITE_PORT=5174
VITE_SITE_URL=http://localhost:5174
ENABLE_QR_SCANNING=true
ENABLE_POOL_CONTRIBUTIONS=true
ENABLE_SKILL_MARKETPLACE=true
ENABLE_TRUST_SCORING=true
```

4. Open MySQL Workbench and connect using `Equinox DBMS`

5. Open [database/schema.sql](C:/Users/saira/Documents/Codex/2026-04-24/equinox-beyond-money-full-system-design/database/schema.sql)

6. Run the full SQL file once. It will:
   create `equinox_dbms`
   create all tables
   create all triggers
   create stored procedures for wallet activation, transfer, pool contribution, contract settlement, and trust recalculation

7. Make sure PHP has the `pdo_mysql` extension enabled. You can check with:

```powershell
php -m
```

8. Start the PHP server from the project root:

```powershell
php -S localhost:3002 router.php
```

9. Open this in the browser:

```text
http://localhost:3002
```

## Main features included

- Glassmorphic dashboard inspired by the shared reference screen
- User registration and login with JWT token
- One-wallet-per-user creation at registration
- Wallet activation through MySQL stored procedure
- P2P transfer through MySQL stored procedure
- Offline QR generation and QR scanning for wallet-based payments
- Virtual card generation with MySQL trigger enforced 3-card maximum
- Card freeze and unfreeze controls
- Immutable transaction ledger
- Community pool creation and contribution
- Skill listing and service contract creation
- Contract settlement through MySQL stored procedure
- Review submission and automatic trust recalculation
- Notification generation from transaction trigger
- Login audit history in MySQL
- Query Demonstrator tab with preset and custom read-only SQL
- Static footer pages for About, Privacy, Terms, Support, and report notes
- Live dashboard refresh in the browser

## Demo flow

1. Register User A and sign in.
2. Activate the wallet to get `500 Eq`.
3. Open `Cards & KYC` and create one virtual card.
4. Open `Eq Wallet` and click `Generate QR`.
5. Register User B in another browser window and activate that wallet too.
6. Scan User B QR from User A or paste User B wallet UUID.
7. Send Eq using the card or direct wallet mode.
8. Open `Query Demonstrator` and run `Recent Ledger` to show real MySQL values.
9. Open `Skill Market`, create a contract, then settle it.
10. Add a review and show the trust score update in `Command Center`.

## Troubleshooting

If the page opens but API calls fail:

- Check `.env` values
- Check MySQL is running on port `3306`
- Check `DB_PASSWORD`
- Check `pdo_mysql` is enabled in PHP

If Workbench connects but SQL fails:

- Run the SQL file from top to bottom without skipping delimiters
- Use MySQL 8.x so `CHECK`, triggers, and `GET DIAGNOSTICS` work cleanly

If PHP says database connection failed:

- Confirm the schema was created
- Confirm the MySQL `root` user can log in from Workbench using the same password

## Optional ZIP

You can create a zip from the project folder with:

```powershell
Compress-Archive -Path * -DestinationPath equinox-beyond-money.zip -Force
```
