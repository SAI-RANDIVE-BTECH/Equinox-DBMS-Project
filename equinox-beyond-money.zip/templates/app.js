const state = {
  token: localStorage.getItem("equinox_token") || "",
  data: null,
  activeSection: "command-center",
  refreshTimer: null,
  scanner: null,
  loadingBootstrap: false,
};

const sectionMeta = {
  "command-center": {
    title: "Command Center",
    subtitle: "Wallet, trust, notifications, security logs, and recent reciprocity activity.",
  },
  "eq-wallet": {
    title: "Eq Wallet",
    subtitle: "Transfer Eq by wallet ID or QR, choose a card, and inspect the transaction audit trail.",
  },
  "cards-kyc": {
    title: "Cards & KYC",
    subtitle: "Generate virtual cards, freeze them instantly, and review identity information.",
  },
  "skill-market": {
    title: "Skill Market",
    subtitle: "List skills, create contracts, settle them atomically, and submit trust-building reviews.",
  },
  "social-pool": {
    title: "Social Pool",
    subtitle: "Create community pools, contribute with live progress bars, and demonstrate trigger updates.",
  },
  "citizen-directory": {
    title: "Citizen Directory",
    subtitle: "Discover peers, inspect trust levels, and prefill payment flows dynamically.",
  },
  "query-lab": {
    title: "Query Demonstrator",
    subtitle: "Run preset or read-only custom SQL and display live MySQL values for the viva.",
  },
  "dbms-evaluation": {
    title: "DBMS Evaluation",
    subtitle: "Rubric, anomalies, normalization, and exact assessment dates aligned to the project notice.",
  },
};

const staticPages = {
  about: {
    title: "About Equinox",
    body: `
      <h4>Beyond Money</h4>
      <p>Equinox is a social-capital wallet where trust, time, and skill move through a MySQL-backed ledger as Equinox Credits (Eq).</p>
      <p>This build demonstrates wallet activation, QR-based transfers, card controls, community pools, service contracts, trust scoring, and audit-friendly database design.</p>
      <p>The goal is to give your DBMS project a product feel while keeping the database operations visible enough for viva and external assessment.</p>
    `,
  },
  privacy: {
    title: "Privacy Policy",
    body: `
      <h4>Project Privacy Scope</h4>
      <p>This student project stores profile, wallet, card, contract, transaction, review, and login-audit data inside the local MySQL schema <code>equinox_dbms</code>.</p>
      <p>Card CVV values are hashed before storage. The dashboard displays masked card numbers after creation.</p>
      <p>Location, device fingerprint, and login activity are stored for audit and fraud-demonstration purposes only inside the local demo environment.</p>
    `,
  },
  terms: {
    title: "Terms of Use",
    body: `
      <h4>Demo Usage Terms</h4>
      <p>The wallet is intended for educational demonstration. Eq is a project currency, not a legal tender.</p>
      <p>All flows such as wallet activation, card generation, and trust recalculation are simulated for the DBMS project but executed through real MySQL tables, procedures, and triggers.</p>
      <p>Use the query demonstrator only for read-only SQL during demonstrations.</p>
    `,
  },
  support: {
    title: "Support",
    body: `
      <h4>Demo Help</h4>
      <p>If a flow appears stuck, first check that MySQL is running, the schema has been imported, and <code>DB_PASSWORD</code> is set correctly in <code>.env</code>.</p>
      <p>For QR issues, use the manual payload option or a raw wallet UUID. For live data checks, open the Query Demonstrator tab and run the wallet or ledger presets.</p>
      <p>The safest demo flow is: register two citizens, activate both wallets, show the QR payment flow, then verify the ledger with the preset queries.</p>
    `,
  },
  report: {
    title: "Project Report Notes",
    body: `
      <h4>Assessment Timeline</h4>
      <p>The notice shared in the request states that the external assessment is scheduled for <strong>April 25, 2026</strong>.</p>
      <p>The same notice says the demonstration and evaluation happen in the lab sessions between <strong>April 20, 2026 and April 24, 2026</strong>, and the report upload deadline listed there is <strong>April 23, 2026 at 11:59 pm</strong>.</p>
      <h4>How this UI supports the report</h4>
      <ul>
        <li>Command Center: shows live balance, trust, and notifications.</li>
        <li>Eq Wallet: demonstrates activation, transfer, and QR payment.</li>
        <li>Cards & KYC: covers banking concepts and trigger enforcement.</li>
        <li>Skill Market and Social Pool: demonstrate contract settlement and pool triggers.</li>
        <li>Query Demonstrator: provides real database values for procedures, joins, and audits.</li>
      </ul>
    `,
  },
};

const ui = {
  authScreen: document.getElementById("auth-screen"),
  appShell: document.getElementById("app-shell"),
  authMessage: document.getElementById("auth-message"),
  registerForm: document.getElementById("register-form"),
  loginForm: document.getElementById("login-form"),
  sidebar: document.getElementById("sidebar"),
  topbarTitle: document.getElementById("topbar-section-title"),
  topbarSubtitle: document.getElementById("topbar-section-subtitle"),
  profileAvatar: document.getElementById("profile-avatar"),
  sidebarUserName: document.getElementById("sidebar-user-name"),
  sidebarTrustLabel: document.getElementById("sidebar-trust-label"),
  availableBalance: document.getElementById("available-balance"),
  walletStatusPill: document.getElementById("wallet-status-pill"),
  kycStatusPill: document.getElementById("kyc-status-pill"),
  trustRing: document.getElementById("trust-ring"),
  trustScoreValue: document.getElementById("trust-score-value"),
  trustScoreTier: document.getElementById("trust-score-tier"),
  trustVolumeLabel: document.getElementById("trust-volume-label"),
  trustRepLabel: document.getElementById("trust-rep-label"),
  trustAgeLabel: document.getElementById("trust-age-label"),
  totalSent: document.getElementById("stat-total-sent"),
  totalReceived: document.getElementById("stat-total-received"),
  ledgerCount: document.getElementById("stat-ledger-count"),
  cardCount: document.getElementById("stat-card-count"),
  recentTransactions: document.getElementById("recent-transactions"),
  notificationFeed: document.getElementById("notification-feed"),
  notificationCountPill: document.getElementById("notification-count-pill"),
  trustFeed: document.getElementById("trust-feed"),
  securityFeed: document.getElementById("security-feed"),
  walletIdFull: document.getElementById("wallet-id-full"),
  walletQrPayload: document.getElementById("wallet-qr-payload"),
  receiverWalletInput: document.getElementById("receiver-wallet-input"),
  paymentNoteInput: document.getElementById("payment-note-input"),
  paymentCardSelect: document.getElementById("payment-card-select"),
  walletCardPreview: document.getElementById("wallet-card-preview"),
  walletTransactionAudit: document.getElementById("wallet-transaction-audit"),
  cardsGrid: document.getElementById("cards-grid"),
  kycName: document.getElementById("kyc-name"),
  kycEmail: document.getElementById("kyc-email"),
  kycPhone: document.getElementById("kyc-phone"),
  kycCity: document.getElementById("kyc-city"),
  kycStatusText: document.getElementById("kyc-status-text"),
  kycWalletStatus: document.getElementById("kyc-wallet-status"),
  skillsGrid: document.getElementById("skills-grid"),
  contractsGrid: document.getElementById("contracts-grid"),
  poolsGrid: document.getElementById("pools-grid"),
  directoryGrid: document.getElementById("directory-grid"),
  queryPresetList: document.getElementById("query-preset-list"),
  queryMeta: document.getElementById("query-meta"),
  querySqlOutput: document.getElementById("query-sql-output"),
  queryTableWrap: document.getElementById("query-table-wrap"),
  qrModal: document.getElementById("qr-modal"),
  qrRender: document.getElementById("qr-render"),
  qrWalletLabel: document.getElementById("qr-wallet-label"),
  scanModal: document.getElementById("scan-modal"),
  qrScanner: document.getElementById("qr-scanner"),
  pageModalTitle: document.getElementById("page-modal-title"),
  pageModalBody: document.getElementById("page-modal-body"),
  contractForm: document.getElementById("contract-form"),
  contractSubtitle: document.getElementById("contract-modal-subtitle"),
  contributeForm: document.getElementById("contribute-form"),
  contributeSubtitle: document.getElementById("contribute-modal-subtitle"),
  reviewForm: document.getElementById("review-form"),
  reviewSubtitle: document.getElementById("review-modal-subtitle"),
  toastStack: document.getElementById("toast-stack"),
  activateWalletBtn: document.getElementById("activate-wallet-btn"),
};

document.querySelectorAll("[data-auth-tab]").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll("[data-auth-tab]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    const tab = button.dataset.authTab;
    ui.registerForm.classList.toggle("hidden", tab !== "register");
    ui.loginForm.classList.toggle("hidden", tab !== "login");
    ui.authMessage.textContent = "";
  });
});

ui.registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(ui.registerForm).entries());
  const response = await api("/api/register", "POST", payload);
  ui.authMessage.textContent = response.success ? response.message : response.error;
  if (response.success) {
    ui.registerForm.reset();
    showToast(response.message, "success");
  } else {
    showToast(response.error || "Registration failed", "error");
  }
});

ui.loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(ui.loginForm).entries());
  const response = await api("/api/login", "POST", payload);
  if (!response.success) {
    ui.authMessage.textContent = response.error || "Login failed";
    showToast(response.error || "Login failed", "error");
    return;
  }

  state.token = response.token;
  localStorage.setItem("equinox_token", response.token);
  ui.authMessage.textContent = "Login successful.";
  showToast("Login successful", "success");
  enterApp();
  await loadDashboard();
});

document.getElementById("payment-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  payload.amount = Number(payload.amount);
  Object.assign(payload, await getCoords());
  const response = await api("/api/wallet/transfer", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Transfer failed", "error");
    return;
  }

  showToast(response.message || "Transfer complete", "success");
  event.target.reset();
  refillCardSelect();
  await loadDashboard({ silent: true });
});

document.getElementById("create-card-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  const response = await api("/api/cards", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Card creation failed", "error");
    return;
  }

  const card = response.card || {};
  showToast(
    `Card ready: ${card.card_number || card.masked_card_number || "New card"} | CVV ${card.cvv || "***"}`,
    "success"
  );
  event.target.reset();
  await loadDashboard({ silent: true });
  switchSection("cards-kyc");
});

document.getElementById("skill-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  payload.rate_per_hour = Number(payload.rate_per_hour);
  const response = await api("/api/skills", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Skill listing failed", "error");
    return;
  }

  showToast(response.message || "Skill published", "success");
  event.target.reset();
  await loadDashboard({ silent: true });
});

document.getElementById("pool-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  payload.target_amount = Number(payload.target_amount);
  if (payload.deadline) {
    payload.deadline = payload.deadline.replace("T", " ") + ":00";
  }
  const response = await api("/api/pools", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Pool creation failed", "error");
    return;
  }

  showToast(response.message || "Pool created", "success");
  event.target.reset();
  await loadDashboard({ silent: true });
});

document.getElementById("custom-query-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  await runQuery(payload.sql || "", "");
});

ui.contractForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(ui.contractForm).entries());
  payload.hours = Number(payload.hours);
  const response = await api("/api/contracts", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Contract creation failed", "error");
    return;
  }

  closeModal("contract-modal");
  showToast(response.message || "Contract created", "success");
  ui.contractForm.reset();
  await loadDashboard({ silent: true });
  switchSection("skill-market");
});

ui.contributeForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(ui.contributeForm).entries());
  payload.amount = Number(payload.amount);
  const response = await api("/api/pools/contribute", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Contribution failed", "error");
    return;
  }

  closeModal("contribute-modal");
  showToast(response.message || "Contribution complete", "success");
  ui.contributeForm.reset();
  await loadDashboard({ silent: true });
  switchSection("social-pool");
});

ui.reviewForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(ui.reviewForm).entries());
  payload.rating = Number(payload.rating);
  const response = await api("/api/reviews", "POST", payload, true);
  if (!response.success) {
    showToast(response.error || "Review submission failed", "error");
    return;
  }

  closeModal("review-modal");
  showToast(response.message || "Review submitted", "success");
  ui.reviewForm.reset();
  await loadDashboard({ silent: true });
});

document.getElementById("manual-scan-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(event.target).entries());
  processScannedPayload(payload.manual_payload || "");
});

ui.activateWalletBtn.addEventListener("click", async () => {
  const coords = await getCoords();
  const response = await api("/api/wallet/activate", "POST", coords, true);
  if (!response.success) {
    showToast(response.error || "Activation failed", "error");
    return;
  }

  showToast(response.message || "Wallet activated", "success");
  await loadDashboard({ silent: true });
});

document.getElementById("show-qr-btn").addEventListener("click", openQrModal);
document.getElementById("show-my-qr-top").addEventListener("click", openQrModal);
document.getElementById("wallet-show-qr-btn").addEventListener("click", openQrModal);
document.getElementById("scan-qr-top").addEventListener("click", openScanModal);
document.getElementById("wallet-scan-qr-btn").addEventListener("click", openScanModal);
document.getElementById("copy-wallet-id-btn").addEventListener("click", () => copyText(ui.walletIdFull.textContent));
document.getElementById("copy-qr-payload-btn").addEventListener("click", () => copyText(ui.qrWalletLabel.textContent));
document.getElementById("nav-new-transfer").addEventListener("click", () => {
  switchSection("eq-wallet");
  ui.receiverWalletInput.focus();
});
document.getElementById("jump-pool-btn").addEventListener("click", () => switchSection("social-pool"));
document.getElementById("logout-btn").addEventListener("click", logout);
document.getElementById("mobile-menu-toggle").addEventListener("click", () => {
  ui.sidebar.classList.toggle("open");
});

document.body.addEventListener("click", async (event) => {
  const modalElement = event.target.classList.contains("modal") ? event.target : null;
  if (modalElement) {
    closeModal(modalElement.id);
    return;
  }

  const closeButton = event.target.closest("[data-close-modal]");
  if (closeButton) {
    closeModal(closeButton.dataset.closeModal);
    return;
  }

  const staticPageButton = event.target.closest("[data-static-page]");
  if (staticPageButton) {
    openStaticPage(staticPageButton.dataset.staticPage);
    return;
  }

  const navButton = event.target.closest("[data-section-target]");
  if (navButton) {
    switchSection(navButton.dataset.sectionTarget);
    if (window.innerWidth <= 1024) {
      ui.sidebar.classList.remove("open");
    }
    return;
  }

  const shortcutButton = event.target.closest("[data-section-shortcut]");
  if (shortcutButton) {
    switchSection(shortcutButton.dataset.sectionShortcut);
    return;
  }

  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) {
    return;
  }

  const action = actionButton.dataset.action;

  if (action === "toggle-card-freeze") {
    const response = await api("/api/cards/freeze", "POST", { card_id: actionButton.dataset.cardId }, true);
    showToast(response.success ? response.message : response.error || "Card update failed", response.success ? "success" : "error");
    if (response.success) {
      await loadDashboard({ silent: true });
    }
    return;
  }

  if (action === "prefill-transfer") {
    prefillTransfer(actionButton.dataset.walletId, actionButton.dataset.name);
    return;
  }

  if (action === "open-contract") {
    openContractModal(actionButton.dataset.skillId, actionButton.dataset.skillName, actionButton.dataset.rate);
    return;
  }

  if (action === "open-contribute") {
    openContributeModal(actionButton.dataset.poolId, actionButton.dataset.poolTitle);
    return;
  }

  if (action === "settle-contract") {
    const response = await api("/api/contracts/settle", "POST", { contract_id: actionButton.dataset.contractId }, true);
    showToast(response.success ? response.message : response.error || "Contract settlement failed", response.success ? "success" : "error");
    if (response.success) {
      await loadDashboard({ silent: true });
    }
    return;
  }

  if (action === "open-review") {
    openReviewModal(actionButton.dataset.contractId, actionButton.dataset.subjectId, actionButton.dataset.subjectName);
    return;
  }

  if (action === "run-preset-query") {
    await runQuery("", actionButton.dataset.presetId);
  }
});

function enterApp() {
  ui.authScreen.classList.add("hidden");
  ui.appShell.classList.remove("hidden");
  switchSection(state.activeSection);
}

function exitApp() {
  ui.appShell.classList.add("hidden");
  ui.authScreen.classList.remove("hidden");
}

function logout() {
  stopScanner();
  clearInterval(state.refreshTimer);
  state.refreshTimer = null;
  state.data = null;
  state.activeSection = "command-center";
  state.token = "";
  localStorage.removeItem("equinox_token");
  exitApp();
  ui.loginForm.reset();
  ui.registerForm.reset();
  ui.authMessage.textContent = "";
  showToast("Signed out", "success");
}

async function loadDashboard(options = {}) {
  if (!state.token || state.loadingBootstrap) {
    return;
  }

  state.loadingBootstrap = true;
  const response = await api("/api/bootstrap", "GET", null, true);
  state.loadingBootstrap = false;

  if (!response.success) {
    if (!options.silent) {
      showToast(response.error || "Unable to load dashboard", "error");
    }
    logout();
    return;
  }

  state.data = response;
  renderAll();
  startAutoRefresh();
}

function renderAll() {
  if (!state.data) {
    return;
  }

  renderProfile(state.data.profile, state.data.insights);
  renderTransactions(state.data.transactions || []);
  renderNotifications(state.data.notifications || []);
  renderTrustHistory(state.data.trust_history || []);
  renderSecurity(state.data.login_history || []);
  renderCards(state.data.cards || []);
  renderSkills(state.data.skills || []);
  renderContracts(state.data.contracts || []);
  renderPools(state.data.pools || []);
  renderDirectory(state.data.directory || []);
  renderQueryPresets(state.data.query_presets || []);
  switchSection(state.activeSection);
}

function renderProfile(profile, insights) {
  const unreadCount = (state.data.notifications || []).filter((item) => Number(item.is_read) === 0).length;
  const trustScore = Number(profile.trust_score || 0);
  const ageDays = Number(insights.account_age_days || 0);
  const trustDegrees = Math.max(10, Math.min(360, trustScore * 3.6));

  ui.profileAvatar.textContent = initials(profile.full_name);
  ui.sidebarUserName.textContent = profile.full_name || "Citizen";
  ui.sidebarTrustLabel.textContent = `Trust Level: ${trustTier(trustScore)}`;
  ui.availableBalance.textContent = formatEq(profile.balance);
  ui.walletStatusPill.textContent = profile.status || "DORMANT";
  ui.kycStatusPill.textContent = `KYC ${profile.kyc_status || "PENDING"}`;
  ui.trustRing.style.background = `conic-gradient(var(--cyan) ${trustDegrees}deg, rgba(255,255,255,0.08) ${trustDegrees}deg 360deg)`;
  ui.trustScoreValue.textContent = String(trustScore);
  ui.trustScoreTier.textContent = trustTier(trustScore);
  ui.trustVolumeLabel.textContent = volumeLabel(Number(insights.ledger_count || 0));
  ui.trustRepLabel.textContent = reputationLabel(trustScore);
  ui.trustAgeLabel.textContent = ageDays > 365 ? `${Math.floor(ageDays / 365)} Yrs` : `${ageDays} Days`;
  ui.totalSent.textContent = `${formatEq(insights.total_sent_eq)} Eq`;
  ui.totalReceived.textContent = `${formatEq(insights.total_received_eq)} Eq`;
  ui.ledgerCount.textContent = String(insights.ledger_count || 0);
  ui.cardCount.textContent = String(insights.card_count || 0);
  ui.notificationCountPill.textContent = `${unreadCount} Unread`;
  ui.walletIdFull.textContent = profile.wallet_id || "-";
  ui.walletQrPayload.textContent = buildQrPayload(profile);
  ui.qrWalletLabel.textContent = buildQrPayload(profile);
  ui.kycName.textContent = profile.full_name || "-";
  ui.kycEmail.textContent = profile.email || "-";
  ui.kycPhone.textContent = profile.phone_number || "Not provided";
  ui.kycCity.textContent = profile.location_city || "Not provided";
  ui.kycStatusText.textContent = profile.kyc_status || "PENDING";
  ui.kycWalletStatus.textContent = profile.status || "DORMANT";
  ui.activateWalletBtn.disabled = profile.status === "ACTIVE";
  ui.activateWalletBtn.textContent = profile.status === "ACTIVE" ? "Wallet Already Active" : "Activate Wallet";
}

function renderTransactions(items) {
  const walletId = state.data?.profile?.wallet_id;
  ui.recentTransactions.innerHTML = items.length
    ? items.map((item) => {
        const incoming = item.receiver_wallet === walletId;
        const amountClass = incoming ? "amount-positive" : "amount-negative";
        const sign = incoming ? "+" : "-";
        const counterpart = incoming ? item.sender_name || "System" : item.receiver_name || "Citizen";
        return `
          <div class="list-item">
            <div>
              <p class="list-title">${escapeHtml(item.transaction_type)} • ${escapeHtml(counterpart)}</p>
              <p class="list-subtitle">${escapeHtml(item.note || "No note")} • ${formatDate(item.created_at)}</p>
              <p class="list-meta">${escapeHtml(item.status)}${item.latitude ? ` • GPS ${escapeHtml(item.latitude)}, ${escapeHtml(item.longitude)}` : ""}</p>
            </div>
            <div class="${amountClass}">${sign}${formatEq(item.amount)} Eq</div>
          </div>
        `;
      }).join("")
    : emptyState("No transactions yet. Activate the wallet or send Eq to start building the ledger.");

  ui.walletTransactionAudit.innerHTML = items.length
    ? items.slice(0, 6).map((item) => `
        <div class="list-item">
          <div>
            <p class="list-title">${escapeHtml(item.transaction_id)}</p>
            <p class="list-subtitle">${escapeHtml(item.transaction_type)} • ${formatDate(item.created_at)}</p>
          </div>
          <div class="list-meta">${escapeHtml(item.status)}</div>
        </div>
      `).join("")
    : emptyState("Transaction audit data will appear here once the ledger has activity.");
}

function renderNotifications(items) {
  ui.notificationFeed.innerHTML = items.length
    ? items.map((item) => `
        <div class="list-item">
          <div>
            <p class="list-title">${escapeHtml(item.title)}</p>
            <p class="list-subtitle">${escapeHtml(item.body)}</p>
          </div>
          <div class="list-meta">${formatDate(item.created_at)}</div>
        </div>
      `).join("")
    : emptyState("No notifications yet.");
}

function renderTrustHistory(items) {
  ui.trustFeed.innerHTML = items.length
    ? items.map((item) => `
        <div class="list-item">
          <div>
            <p class="list-title">${escapeHtml(item.reason)}</p>
            <p class="list-subtitle">${formatDate(item.created_at)}</p>
          </div>
          <div class="${Number(item.score_delta) >= 0 ? "amount-positive" : "amount-negative"}">
            ${Number(item.score_delta) >= 0 ? "+" : ""}${escapeHtml(String(item.score_delta))}
          </div>
        </div>
      `).join("")
    : emptyState("Reviews and contract activity will generate trust history entries.");
}

function renderSecurity(items) {
  ui.securityFeed.innerHTML = items.length
    ? items.map((item) => `
        <div class="list-item">
          <div>
            <p class="list-title">${escapeHtml(shortDevice(item.device_fingerprint || "Unknown device"))}</p>
            <p class="list-subtitle">${escapeHtml(item.ip_address || "Localhost")} • ${escapeHtml(item.login_status)}</p>
          </div>
          <div class="list-meta">${formatDate(item.created_at)}</div>
        </div>
      `).join("")
    : emptyState("Login activity will appear here after sign-in events.");
}

function renderCards(cards) {
  ui.paymentCardSelect.innerHTML = `<option value="">Use wallet directly</option>`;

  cards.forEach((card) => {
    if (!card.is_frozen) {
      ui.paymentCardSelect.insertAdjacentHTML(
        "beforeend",
        `<option value="${escapeHtml(card.card_id)}">${escapeHtml(card.card_name)} • ${escapeHtml(card.masked_card_number)}</option>`
      );
    }
  });

  const cardHtml = cards.length
    ? cards.map((card) => `
        <div class="bank-card ${card.is_frozen ? "frozen" : ""}">
          <div class="data-card-header">
            <div>
              <div class="bank-card-label">${escapeHtml(card.brand)} • ${escapeHtml(card.card_name)}</div>
              <div class="bank-card-number">${escapeHtml(card.masked_card_number)}</div>
            </div>
            <span class="pill ${card.is_frozen ? "muted" : "cyan"}">${card.is_frozen ? "Frozen" : "Active"}</span>
          </div>
          <div class="bank-card-meta">
            <span>Expiry ${escapeHtml(card.expiry_date)}</span>
            <span>${formatDate(card.created_at)}</span>
          </div>
          <div class="top-space">
            <button class="button ghost small" data-action="toggle-card-freeze" data-card-id="${escapeHtml(card.card_id)}">
              ${card.is_frozen ? "Unfreeze Card" : "Freeze Card"}
            </button>
          </div>
        </div>
      `).join("")
    : emptyState("No virtual cards yet. Create one in the Cards & KYC section.");

  ui.walletCardPreview.innerHTML = cardHtml;
  ui.cardsGrid.innerHTML = cardHtml;
}

function renderSkills(skills) {
  const currentUser = state.data?.profile?.user_id;
  ui.skillsGrid.innerHTML = skills.length
    ? skills.map((skill) => {
        const isMine = skill.user_id === currentUser;
        return `
          <div class="data-card">
            <div class="data-card-header">
              <div>
                <strong>${escapeHtml(skill.skill_name)}</strong>
                <p>${escapeHtml(skill.full_name)}</p>
              </div>
              <span class="pill cyan">${formatEq(skill.rate_per_hour)} Eq/hr</span>
            </div>
            <p>${escapeHtml(skill.description || "No description provided.")}</p>
            <div class="data-card-header">
              <span class="list-meta">${formatDate(skill.created_at)}</span>
              ${
                isMine
                  ? `<span class="pill muted">Your Listing</span>`
                  : `<button class="button ghost cyan small" data-action="open-contract" data-skill-id="${escapeHtml(skill.skill_id)}" data-skill-name="${escapeHtml(skill.skill_name)}" data-rate="${escapeHtml(String(skill.rate_per_hour))}">Create Contract</button>`
              }
            </div>
          </div>
        `;
      }).join("")
    : emptyState("No skills listed yet. Publish one to demonstrate the marketplace.");
}

function renderContracts(contracts) {
  const currentUser = state.data?.profile?.user_id;
  ui.contractsGrid.innerHTML = contracts.length
    ? contracts.map((contract) => {
        const isConsumer = contract.consumer_id === currentUser;
        const counterpartName = isConsumer ? contract.provider_name : contract.consumer_name;
        const reviewSubjectId = isConsumer ? contract.provider_id : contract.consumer_id;
        return `
          <div class="data-card">
            <div class="data-card-header">
              <div>
                <strong>${escapeHtml(contract.skill_name)}</strong>
                <p>${escapeHtml(counterpartName)} • ${escapeHtml(contract.status)}</p>
              </div>
              <span class="pill">${formatEq(contract.total_eq)} Eq</span>
            </div>
            <p>${escapeHtml(contract.hours)} hour(s) • ${formatDate(contract.created_at)}</p>
            <div class="data-card-header">
              ${
                contract.status === "COMPLETED"
                  ? `<button class="button ghost cyan small" data-action="open-review" data-contract-id="${escapeHtml(contract.contract_id)}" data-subject-id="${escapeHtml(reviewSubjectId)}" data-subject-name="${escapeHtml(counterpartName)}">Add Review</button>`
                  : `<button class="button primary small" data-action="settle-contract" data-contract-id="${escapeHtml(contract.contract_id)}">Settle Contract</button>`
              }
              <span class="list-meta">${isConsumer ? "Consumer" : "Provider"} View</span>
            </div>
          </div>
        `;
      }).join("")
    : emptyState("No contracts yet. Hire a skill listing to demonstrate contract settlement.");
}

function renderPools(pools) {
  ui.poolsGrid.innerHTML = pools.length
    ? pools.map((pool) => `
        <div class="data-card">
          <div class="data-card-header">
            <div>
              <strong>${escapeHtml(pool.title)}</strong>
              <p>${escapeHtml(pool.creator_name)}</p>
            </div>
            <span class="pill ${pool.status === "COMPLETED" ? "cyan" : ""}">${escapeHtml(pool.status)}</span>
          </div>
          <p>${escapeHtml(pool.description || "No description provided.")}</p>
          <div class="progress-track">
            <div class="progress-fill" style="width: ${Math.min(100, Number(pool.progress_percent || 0))}%"></div>
          </div>
          <div class="data-card-header">
            <span class="list-meta">${formatEq(pool.raised_amount)} / ${formatEq(pool.target_amount)} Eq • ${pool.contribution_count} contributions</span>
            ${
              pool.status === "ACTIVE"
                ? `<button class="button ghost cyan small" data-action="open-contribute" data-pool-id="${escapeHtml(pool.pool_id)}" data-pool-title="${escapeHtml(pool.title)}">Contribute</button>`
                : `<span class="pill cyan">Completed</span>`
            }
          </div>
        </div>
      `).join("")
    : emptyState("No pools available yet. Create one to demonstrate trigger-driven funding totals.");
}

function renderDirectory(directory) {
  ui.directoryGrid.innerHTML = directory.length
    ? directory.map((citizen) => `
        <div class="data-card">
          <div class="data-card-header">
            <div>
              <strong>${escapeHtml(citizen.full_name)}</strong>
              <p>${escapeHtml(citizen.location_city || "City not set")} • ${escapeHtml(citizen.kyc_status)}</p>
            </div>
            <span class="pill cyan">${escapeHtml(String(citizen.trust_score))}</span>
          </div>
          <p>${escapeHtml(citizen.skill_count)} active skill listing(s) • Wallet ${escapeHtml(citizen.wallet_status)}</p>
          <div class="data-card-header">
            <button class="button ghost small" data-action="prefill-transfer" data-wallet-id="${escapeHtml(citizen.wallet_id)}" data-name="${escapeHtml(citizen.full_name)}">Pay Citizen</button>
            <span class="list-meta">${escapeHtml(shortId(citizen.wallet_id))}</span>
          </div>
        </div>
      `).join("")
    : emptyState("No other citizens found yet. Register a second account for the group demo.");
}

function renderQueryPresets(presets) {
  ui.queryPresetList.innerHTML = presets.length
    ? presets.map((preset) => `
        <button class="query-chip" data-action="run-preset-query" data-preset-id="${escapeHtml(preset.id)}">
          <strong>${escapeHtml(preset.label)}</strong>
          <span>${escapeHtml(preset.description)}</span>
        </button>
      `).join("")
    : emptyState("Query presets will appear after bootstrap.");
}

function switchSection(sectionId) {
  state.activeSection = sectionId;
  document.querySelectorAll("[data-section]").forEach((section) => {
    section.classList.toggle("hidden", section.dataset.section !== sectionId);
    section.classList.toggle("active", section.dataset.section === sectionId);
  });

  document.querySelectorAll("[data-section-target]").forEach((button) => {
    button.classList.toggle("active", button.dataset.sectionTarget === sectionId);
  });

  const meta = sectionMeta[sectionId] || sectionMeta["command-center"];
  ui.topbarTitle.textContent = meta.title;
  ui.topbarSubtitle.textContent = meta.subtitle;
}

async function runQuery(sql, preset) {
  const payload = preset ? { preset } : { sql };
  const response = await api("/api/query-demonstrator", "POST", payload, true);
  if (!response.success) {
    ui.queryMeta.textContent = response.error || "Query execution failed";
    ui.querySqlOutput.textContent = "";
    ui.queryTableWrap.innerHTML = emptyState("No query result to display.");
    showToast(response.error || "Query execution failed", "error");
    switchSection("query-lab");
    return;
  }

  renderQueryResult(response);
  switchSection("query-lab");
  showToast("Query executed successfully", "success");
}

function renderQueryResult(result) {
  ui.queryMeta.textContent = `${result.row_count} row(s) • Executed ${formatDate(result.executed_at)}`;
  ui.querySqlOutput.textContent = result.query || "";

  if (!result.columns || !result.columns.length) {
    ui.queryTableWrap.innerHTML = emptyState("No table columns returned.");
    return;
  }

  const header = result.columns.map((column) => `<th>${escapeHtml(column)}</th>`).join("");
  const rows = (result.rows || []).length
    ? result.rows.map((row) => `
        <tr>
          ${result.columns.map((column) => `<td>${escapeHtml(normalizeCell(row[column]))}</td>`).join("")}
        </tr>
      `).join("")
    : `<tr><td colspan="${result.columns.length}">No rows returned.</td></tr>`;

  ui.queryTableWrap.innerHTML = `
    <table>
      <thead><tr>${header}</tr></thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

function openQrModal() {
  if (!state.data?.profile) {
    return;
  }

  const payload = buildQrPayload(state.data.profile);
  ui.qrRender.innerHTML = "";
  ui.qrWalletLabel.textContent = payload;

  if (typeof QRCode !== "undefined") {
    new QRCode(ui.qrRender, {
      text: payload,
      width: 220,
      height: 220,
      colorDark: "#00f1fe",
      colorLight: "#0b0f1b",
      correctLevel: QRCode.CorrectLevel.H,
    });
  } else {
    ui.qrRender.innerHTML = emptyState("QR generator not available. Copy the wallet payload instead.");
  }

  openModal("qr-modal");
}

function openScanModal() {
  openModal("scan-modal");
  startScanner();
}

function openStaticPage(pageId) {
  const page = staticPages[pageId] || staticPages.about;
  ui.pageModalTitle.textContent = page.title;
  ui.pageModalBody.innerHTML = page.body;
  openModal("page-modal");
}

function openContractModal(skillId, skillName, rate) {
  ui.contractForm.reset();
  ui.contractForm.elements.skill_id.value = skillId || "";
  ui.contractSubtitle.textContent = `${skillName || "Selected skill"} • ${formatEq(rate || 0)} Eq per hour`;
  openModal("contract-modal");
}

function openContributeModal(poolId, poolTitle) {
  ui.contributeForm.reset();
  ui.contributeForm.elements.pool_id.value = poolId || "";
  ui.contributeSubtitle.textContent = `Pool: ${poolTitle || "Selected pool"}`;
  openModal("contribute-modal");
}

function openReviewModal(contractId, subjectId, subjectName) {
  ui.reviewForm.reset();
  ui.reviewForm.elements.contract_id.value = contractId || "";
  ui.reviewForm.elements.subject_id.value = subjectId || "";
  ui.reviewSubtitle.textContent = `Reviewing ${subjectName || "counterparty"} after contract settlement`;
  openModal("review-modal");
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove("hidden");
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add("hidden");
  }

  if (modalId === "scan-modal") {
    stopScanner();
  }
}

function prefillTransfer(walletId, name) {
  switchSection("eq-wallet");
  ui.receiverWalletInput.value = walletId || "";
  ui.paymentNoteInput.value = name ? `Payment to ${name}` : "";
  ui.receiverWalletInput.focus();
  showToast("Transfer form prefilled from citizen directory", "success");
}

function refillCardSelect() {
  ui.paymentCardSelect.value = "";
}

function buildQrPayload(profile) {
  return JSON.stringify({
    wallet_id: profile.wallet_id,
    display_name: profile.full_name,
    type: "EQUINOX_WALLET",
    version: "1.0",
  });
}

function processScannedPayload(decodedText) {
  const parsed = parseQrPayload(decodedText);
  if (!parsed) {
    showToast("Unsupported QR payload. Use an Equinox wallet QR or raw wallet UUID.", "error");
    return;
  }

  if (parsed.walletId) {
    prefillTransfer(parsed.walletId, parsed.displayName || "");
    if (parsed.displayName) {
      ui.paymentNoteInput.value = `Payment to ${parsed.displayName}`;
    }
    closeModal("scan-modal");
    showToast("Receiver wallet loaded from QR", "success");
    return;
  }

  if (parsed.upiReference) {
    switchSection("eq-wallet");
    ui.paymentNoteInput.value = `UPI reference scanned: ${parsed.upiReference}`;
    closeModal("scan-modal");
    showToast("UPI reference captured. Add the Equinox receiver wallet before payment.", "success");
  }
}

function parseQrPayload(decodedText) {
  const text = String(decodedText || "").trim();
  if (!text) {
    return null;
  }

  try {
    const data = JSON.parse(text);
    if (data.type === "EQUINOX_WALLET" && isUuid(data.wallet_id)) {
      return {
        walletId: data.wallet_id,
        displayName: data.display_name || "",
      };
    }
  } catch (_) {
  }

  if (/^upi:\/\//i.test(text)) {
    try {
      const url = new URL(text);
      return {
        upiReference: url.searchParams.get("pa") || url.searchParams.get("pn") || "UPI QR",
      };
    } catch (_) {
    }
  }

  if (isUuid(text)) {
    return { walletId: text, displayName: "" };
  }

  return null;
}

function startScanner() {
  stopScanner();
  ui.qrScanner.innerHTML = "";

  if (typeof Html5QrcodeScanner === "undefined") {
    ui.qrScanner.innerHTML = emptyState("QR scanner library did not load. Use the manual payload option.");
    return;
  }

  state.scanner = new Html5QrcodeScanner(
    "qr-scanner",
    {
      fps: 10,
      qrbox: { width: 240, height: 240 },
      rememberLastUsedCamera: true,
    },
    false
  );

  state.scanner.render(
    (decodedText) => processScannedPayload(decodedText),
    () => {}
  );
}

function stopScanner() {
  if (state.scanner && typeof state.scanner.clear === "function") {
    try {
      state.scanner.clear();
    } catch (_) {
    }
  }
  state.scanner = null;
}

function startAutoRefresh() {
  if (state.refreshTimer) {
    clearInterval(state.refreshTimer);
  }

  state.refreshTimer = setInterval(() => {
    if (state.token) {
      loadDashboard({ silent: true });
    }
  }, 10000);
}

async function copyText(text) {
  if (!text) {
    return;
  }

  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied to clipboard", "success");
  } catch (_) {
    showToast("Clipboard copy failed", "error");
  }
}

async function getCoords() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve({ latitude: null, longitude: null });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      () => resolve({ latitude: null, longitude: null }),
      { enableHighAccuracy: false, timeout: 4000 }
    );
  });
}

async function api(url, method = "GET", payload = null, auth = false) {
  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
    },
  };

  if (auth && state.token) {
    options.headers.Authorization = `Bearer ${state.token}`;
  }

  if (payload && method !== "GET") {
    options.body = JSON.stringify(payload);
  }

  try {
    const response = await fetch(url, options);
    return await response.json();
  } catch (error) {
    return { success: false, error: error.message };
  }
}

function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  ui.toastStack.appendChild(toast);
  window.setTimeout(() => toast.remove(), 3200);
}

function formatEq(value) {
  return Number(value || 0).toFixed(2);
}

function formatDate(value) {
  if (!value) {
    return "Unknown time";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function trustTier(score) {
  if (score >= 85) return "Radiant";
  if (score >= 70) return "Resonant";
  if (score >= 55) return "Stable";
  return "Neutral";
}

function volumeLabel(count) {
  if (count >= 20) return "High";
  if (count >= 8) return "Growing";
  if (count >= 1) return "Building";
  return "New";
}

function reputationLabel(score) {
  if (score >= 85) return "Stellar";
  if (score >= 70) return "Strong";
  if (score >= 55) return "Healthy";
  return "Stable";
}

function initials(name) {
  return String(name || "Equinox")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("");
}

function shortDevice(device) {
  return String(device).replace(/\s+/g, " ").slice(0, 48);
}

function shortId(id) {
  if (!id || id.length < 12) {
    return id || "-";
  }
  return `${id.slice(0, 8)}...${id.slice(-4)}`;
}

function normalizeCell(value) {
  if (value === null || value === undefined) {
    return "";
  }
  if (typeof value === "object") {
    return JSON.stringify(value);
  }
  return String(value);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function emptyState(message) {
  return `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function isUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ""));
}

if (state.token) {
  enterApp();
  loadDashboard();
}
